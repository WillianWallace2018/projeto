<?php 
include("header.php");

?>
<!--SLIDE-->
<div class="slider fullscreen">
    <ul class="slides">
        <li>
            <img src="img/livro1.jpg"> <!-- random image -->
            <div class="caption center-align">
                <h3>QUANDO VOCÊ PENSA EM LIVROS</h3>
                <h5 class="light grey-text text-lighten-3">VOCÊ PENSA NA GAPSS</h5>
            </div>
        </li>
        <li>
            <img src="img/livro2.jpg"> <!-- random image -->
            <div class="caption left-align">
                <h3>ENTRE EM UMA GRANDE JORNADA</h3>
                <h5 class="light grey-text text-lighten-3">COM NOSSOS LIVROS.</h5>
            </div>
        </li>
        <li>
            <img src="img/livro3.jpg"> <!-- random image -->
            <div class="caption right-align">
                <h3>APRECIE NOSSOS LIVROS</h3>
                <h5 class="light grey-text text-lighten-3">E SE TORNE UM CLIENTE GAPS</h5>
            </div>
        </li>
        <li>
            <img src="img/livro4.jpg"> <!-- random image -->
            <div class="caption center-align">
                <h3>INCENTIVE OUTRA PESSOA</h3>
                <h5 class="light grey-text text-lighten-3">A LER COM A GAPSS</h5>
            </div>
        </li>
    </ul>
</div>
<!--PRODUTOS EM DESTAQUE-->
<section class="equipe light-blue darken-1">
    <div id="destaque">
    <div class="container">
        <div class="row">
            <div class="col s12">
                <h2 style="margin-top: 8%;" class="center-align">DESTAQUES DA SEMANA</h2>
                <p  class="flow-text center align">
                    Os produtos mais vendidos da livraria
                </p>
            </div>
        </div>
    </div>
    <div class="row" style="clear: both">
        <div class="col s12 m3">
            <div class="card">
                <div class="card-image">
                    <img src="img/py54657uht.jpg" class="img1">
                </div>
                <div class="card-content">
                    <p>A CULPA É DAS ESTRELAS</p>
                </div>
                <div class="card-action">
                    <a href="product.php?livro=3" class="btn waves-effect waves-light">SAIBA MAIS<i class="material-icons right">send</i></a>
                </div>
            </div>
        </div>
        <div class="col s12 m3">
            <div class="card">
                <div class="card-image">
                    <img src="img/9sdjnsdjwe2.jpg" class="img2">
                </div>
                <div class="card-content">
                    <p>GUERRA INFINITA</p>
                </div>
                <div class="card-action">
                    <a href="product.php?livro=29" class="btn waves-effect waves-light">SAIBA MAIS<i class="material-icons right">send</i></a>
                </div>
            </div>
        </div>
        <div class="col s12 m3">
            <div class="card">
                <div class="card-image">
                    <img src="img/td56wt6r.jpg" class="img3">
                </div>
                <div class="card-content">
                    <p>MISTÉRIO DE ELÊUSIS</p>
                </div>
                <div class="card-action">
                    <a href="product.php?livro=17" class="btn waves-effect waves-light">SAIBA MAIS<i class="material-icons right">send</i></a>
                </div>
            </div>
        </div>
        <div class="col s12 m3">
            <div class="card">
                <div class="card-image">
                    <img src="img/kfj48it485.jpg" class="img4">
                </div>
                <div class="card-content">
                    <p>A MASCARA DO ZORRO</p>
                </div>
                <div class="card-action">
                    <a href="product.php?livro=50" class="btn waves-effect waves-light">SAIBA MAIS<i class="material-icons right">send</i></a>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<!--SOBRE A EMPRESA-->
<section class="light-blue darken-1">
    <div class="container">
        <div class="row" >
            <div class="col s12" >
                <h2 class="center-align" >SOBRE A EMPRESA</h2>
                <p  class="flow-text center align">CONHEÇA A GAPSS</p>
            </div>
        </div>
        <div class="row">
            <ul class="collapsible">
                <li>
                    <div id="sobre" class="collapsible-header grey lighten-4"><i class="material-icons">control_point</i>QUEM SOMOS?</div>
                    <div class="collapsible-body white"><span>Somos uma empresa especializada em Livros, que foi fundada dia 13 de novembro de 2017 e que faz o possivel para corresponder aos desejos de nossos clientes, para que ele<br> sempre saía com o maximo possível de satisfação. O lema da nossa empresa é: "100% de comprometimento com o cliente",  </span></div>
                </li>
                <li>
                    <div class="collapsible-header grey lighten-4"><i class="material-icons">control_point</i>IFSP CARAGUATATUBA</div>
                    <div class="collapsible-body white"><span>O IFSP foi criado originalmente como a Escola de Aprendizes e Artífices de São Paulo, por meio do Decreto-lei nº 7.566, assinado pelo presidente Nilo Peçanha em 23 de setembro de 1909. O decreto determinou a criação em cada uma das capitais dos Estados da República uma "Escola de Aprendizes Artífices", para que ali fosse ministrado ensino profissional primário.
                    O início efetivo de suas atividades ocorreu no ano de 1910. Nos primeiros meses, a escola funcionou provisoriamente em um galpão instalado na Avenida Tiradentes, no Bairro da Luz, sendo transferida no mesmo ano para o bairro de Santa Cecília, na Rua General Júlio Marcondes Salgado, onde permaneceu até o final de 1975. Os primeiros cursos foram de Tornearia, Mecânica e Eletricidade, além das oficinas de Carpintaria e Artes Decorativas, sendo o corpo discente composto de quase uma centena de aprendizes. A Escola teve seu projeto voltado para a formação de operários e contramestres.
                    A partir de 1937 houve uma série de mudanças, quando a escola se transformou em Liceu Industrial de São Paulo. Logo em seguida, a Escola Industrial de São Paulo (1942) veio a substituí-lo, e, no transcorrer do tempo, foi transformada em Escola Técnica de São Paulo (1942). Ainda nesse processo de mudança, houve uma nova alteração para Escola Técnica Federal de São Paulo (1965).
                    Estabelecida em 1965, a Escola Técnica Federal de São Paulo formou, entre os anos 60 a 90, técnicos de nível médio, inicialmente para as áreas de Mecânica e Edificações, depois para Eletrotécnica, Eletrônica, Telecomunicações, Processamento de Dados e Informática Industrial.
                    Em 1987 a Escola inaugurou sua segunda unidade, localizada no município de Cubatão, litoral paulista, e, em 1996, a terceira unidade, em Sertãozinho, no interior do Estado.
                    Nesse período, houve o reconhecimento público da Escola Técnica Federal de São Paulo pelo excelente preparo profissional de seus alunos. Registre-se o fato de que, até hoje, ela ainda é conhecida popularmente como Escola Técnica Federal ou Federal de São Paulo.</span></div>
                </li>
                <li>
                    <div class="collapsible-header grey lighten-4"><i class="material-icons">control_point</i>LIVRARIA GAPSS</div>
                    <div class="collapsible-body white"><span>Somos uma livraria independente que começou a vender em um pequeno espaço e com o passar do tempo conseguimos almentar a loja de tal maneira que foi necessário expandir a loja para um local maior e então uma decisão foi tomada deixar a livraria GAPSS seria apenas um e-commerce.</span></div>
                </li>
            </ul>
        </div>
    </div>
</section>
<!--Localização-->
<section class="localizacao grey lighten-4">
    <div id="localizacao">
        <div class="container">
            <div class="row">
                <h2 class="center-align">Localização</h2>
                <p class="flow-text center-align">Saiba onde estamos</p>
            </div>

            <div class="row">
                <div class="col s12 m8">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3655.0917512177207!2d-45.428097684563305!3d-23.63688498464547!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94cd631551d2d585%3A0xbe6efd4b81fb3cd0!2sInstituto+Federal+de+Educa%C3%A7%C3%A3o%2C+Ci%C3%AAncia+e+Tecnologia+de+S%C3%A3o+Paulo%2C+Campus+Caraguatatuba!5e0!3m2!1spt-BR!2sbr!4v1542291549963" width="100%" height="450" frameborder="0" style="border:0" class="z-depth-3" allowfullscreen></iframe>
                </div>

                <div class="col s12 m4">
                <div class="chip chip-custom">
                    A. Bahia, 11739 - Indaiá
                    <i class="close material-icons">location_on</i>
                </div>
                <div class="chip chip-custom">
                    Caraguatatuba
                    <i class="close material-icons">location_on</i>
                </div>
                <div class="chip chip-custom">
                    São Paulo
                    <i class="close material-icons">location_on</i>
                </div>
                <div class="chip chip-custom">
                    +55 12 4002-8922
                    <i class="close material-icons">call</i>
                </div>
                </div>
            </div>
        </div>
    </div>
</section>



<!--Rodapé-->
<?php 
    include("footer.php");
?>


