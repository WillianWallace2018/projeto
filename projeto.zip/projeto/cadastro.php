<!DOCTYPE html>
<html>
<head>
  <title>teste</title>
  <link rel="stylesheet" type="text/css" href="css/materialize.css">
  <link rel="stylesheet" type="text/css" href="css/materialize.min.css">
  <link rel="stylesheet" type="text/css" href="css/cad.css">
  <meta charset="utf-8">
</head>
<body class="center-form">
  <div class="center-form">

<?php 
	if (isset($_GET['erro'])){
		switch ($_GET['erro']) {
			case 'usuarioExiste':
				alertar("Usuario ja cadastrado");
				break;
			case 'email':
				alertar("Formato de e-mail incorreto");
				break;
			case 'charInvalido':
				alertar("O nome deve conter apenas letras");
				break;
			case 'vazio':
				alertar("Preencha todos os campos");
				break;
			case 'error':
				alertar("Não foi possivel cadastrar agora. Tente mais tarde");
				break;
			default:
				alertar("Caminho invalido");
				break;
		}
	}
	
	function alertar($msg){
		echo '<script type="text/javascript">setTimeout(function(){ alert("'.$msg.'");}, 500);</script>';
	}
?>

    <form action="signup.php" method="post">
      <h2 class="Hs">Cadastre-se</h2>
      <div class="row">
          <input type="text" name="name" required class="validate" placeholder="Nome Completo">
      </div>

      <div class="row">
          <input type="text" name="uid" required class="validate" placeholder="Usuário">
      </div>

      <div class="row">
          <input type="password" name="pwd" required class="validate" placeholder="Senha">
      </div>

      <div class="row">
          <input type="text" name="email" required class="validate" placeholder="Email">
      </div>
      <div class="botao"><button type="submit" name="submit">Enviar</button></div>
    </form>
  </div>
</body>
</html>