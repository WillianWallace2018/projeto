<?php

if (isset($_POST['submit'])){
	
	//inclui a conexão
	$dbServername = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbName = "users";

	$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

	
	//real_escape não permite sql inject
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$uid = mysqli_real_escape_string($conn, $_POST['uid']);
	$pwd = mysqli_real_escape_string($conn, $_POST['pwd']);
	
	//error handlers
	//checa espaço vazio
	if(empty($name) || empty($email) || empty($uid) || empty($pwd)){
		header("Location: cadastro.php?erro=vazio");
		exit();
	} else {
		//checa se caracteres são validos
		if(!preg_match("/^[a-zA-Z ]*$/", $name)){
			header("Location: cadastro.php?erro=charInvalido");
			exit();
		} else {
			//checa se email é valido
			if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
				header("Location: cadastro.php?erro=email");
				exit();
			} else{
				//checa se usuario já existe no db
				$sql = "SELECT * FROM users WHERE uid='$uid'";
				$result = mysqli_query($conn, $sql);
				$resultCheck = mysqli_num_rows($result);
				
				//se encontra uid no db manda erro
				
				//
				
				// to lower
				
				//
				if($resultCheck > 0 || $uid == "admin"){
					header("Location: cadastro.php?erro=usuarioExiste");
					exit();
				} else {
					//encripta senha
					$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
					//insere o usuario na db, *nota com  a hashedPwd
					$sql = "INSERT INTO users (name, email, uid, pwd) VALUES ('$name', '$email', '$uid', '$hashedPwd');";
					$result = mysqli_query($conn, $sql);
					header("Location: index.php?erro=cadastroOk");
					//
					
					// manda mensagem de sucesso
					
					//
					
					exit();
				}
			}
		}
	}
	
} else{
	header("Location: index.php");
	exit();
}