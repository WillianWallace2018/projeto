<?php 

session_start();

if(isset($_POST['addToCart'])){
	if(isset($_POST['bookId'])){
		$bookId = $_POST['bookId'];
	} else{
		header("Location: new404.php");
	}

	if(isset($_SESSION['id'])){
		$clientId = $_SESSION['id'];
	}

	$dbServername = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbName = "users";

	$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

	$sql = "INSERT INTO pedidos(clientId, productId) values ($clientId, $bookId)";
	$result = mysqli_query($conn, $sql);

	if($result){
		header("Location: index.php?erro=compraFinalizada");
	} else{
		header("Location: index.php?erro=compraInvalida");
	}


}else{
	header("Location: new404.php");
}


 ?>