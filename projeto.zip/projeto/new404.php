<?php 
include 'header.php';

echo '<div style=" margin:20%"><h2 style="text-align: center">OPS! Essa página não existe</h2>';
echo '<img src="img/erro404.png" style="transform: translateX(-50%); position: relative; left: 50%;"</div>';


include 'footer.php';

 ?>