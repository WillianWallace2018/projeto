</div>
<footer id="footer">
	<div class="socialFooter">
		<ul>
			<li><a href="https://www.facebook.com/Livraria-GAPSS-553130601804140/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
			<li><a href="https://www.reddit.com/user/LIVRARIAGAPSS" target="_blank"><i class="fab fa-reddit"></i></a></li>
			<li><a href="https://plus.google.com/u/0/110688257558975538383" target="_blank"><i class="fab fa-google-plus-g"></i></a></li>
			<li><a href="http://br.pinterest.com/lggapss/" target="_blank" ><i class="fab fa-pinterest-p"></i></a></li>
			<li><a href="https://www.instagram.com/livrariagapss/?hl=pt-br" target="_blank"><i class="fab fa-instagram"></i></a></li>
			<li><a href="https://www.tumblr.com/blog/livrariagapss" target="_blank"><i class="fab fa-tumblr"></i></a></li>
			<li><a href="https://www.linkedin.com/help/linkedin" target="_blank" ><i class="fab fa-linkedin-in"></i></a></li>

		</ul>
	</div>
	<div class="linksFooter">
		<ul style="float: left;">
			<li><a class="links" href="livros.php?category=acao&?page=1">A&Ccedil;&Atilde;O</a></li>
			<li><a class="links" href="livros.php?category=aventura&?page=1">AVENTURA</a></li>
			<li><a class="links" href="livros.php?category=aventura&?page=1">COM&Eacute;DIA</a></li>
			<li><a class="links" href="livros.php?category=romance&?page=1">ROMANCE</a></li>
			<li><a class="links" href="livros.php?category=suspense&?page=1">SUSPENSE</a></li>
		</ul>
		<ul style="float: right;">
		<li><a href="index.php#destaque">DESTAQUES</a></li>
        <li><a href="index.php#sobre">SOBRE</a></li>
        <li><a href="index.php#localizacao">LOCALIZA&Ccedil;&Atilde;O</a></li>
        <li><a href="index.php#footer">FALE CONOSCO</a></li>
		</ul>
	</div>
<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "users";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);



	echo'<div class="newsletterContainer">
		<h1>Novidades</h1>
		<h2>Cadastre seu e-mail agora para n&atilde;o perder nenhuma promo&ccedil;&atilde;o!</h2>
		<form class="newsletterForm" method="POST" action="newsletter.php">
			<input type="text" name="nlEmail" placeholder="Seu E-mail">
			<button type="submit" name="nlButton">Enviar</button>
		</form>
	</div>';

?>

</footer>
<div class="footer-copyright">
    <div class="container" style="text-align: center;">
    	&copy; 2018 Copyright - Gustavo Dantas, Andr&eacute; Duarte, Pablo Nicolay, Saulo Henrique e Savio Henrique.
	</div>
</div>

<!-- BOTÃO ANCORA -->
<a class="btn-floating btn-large cyan pulse" href="#brand-logo"><i class="material-icons">expand_less</i></a>

<!--JAVA SCRIPT--> 
<!-- Compiled and minified JavaScript -->
<!--JavaScript at end of body for optimized loading-->
<script     
    src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous">
</script>

<script type="text/javascript" src="js/materialize.min.js"></script>
    <script>
        $(document).ready(function()
            {
                $(".dropdown-trigger").dropdown({hover: true});
                $('.sidenav').sidenav();
                $('.slider').slider();
                $('.collapsible').collapsible()
            });

		  document.addEventListener('DOMContentLoaded', function() {
		    var elems = document.querySelectorAll('.materialboxed');
		    var instances = M.Materialbox.init(elems, options);
		  });

		  // Or with jQuery

		  $(document).ready(function(){
		    $('.materialboxed').materialbox();
		  });
        
	</script> 

</body>

</html>
