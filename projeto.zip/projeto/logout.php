<?php
if(isset($_GET['log'])){
	if($_GET['log'] == 'out'){

		session_start();
		session_unset();
		session_destroy();
		header("Location: index.php");
	}

}




