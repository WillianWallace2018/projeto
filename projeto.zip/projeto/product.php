<?php session_start(); ?>
<html>
<head>
    <meta name="description" content="Livraria GAPSS">
    <meta name="keywords" content="Livros, Downloads, PDF, Comprar, Baixar">
    <meta name="author" content="André, Gustavo, Pablo, Saulo e Savio">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	
    <?php header("Content-type: text/html; charset=iso-8859-1"); ?>
    <meta charset="utf-8">
    <!--ICONES GOOGLE -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Patua+One|Roboto" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Materialize CSS-->
    <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
    <link type="text/css" rel="stylesheet" href="css/style.css"/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
        <title>PROJETO - Livraria GASSP</title>
    
</head>

<body>

<!-- Dropdown Structure -->
<ul id="dropdown1" class="dropdown-content">
  <li style="background: rgba(12, 162, 196, 1); height: 65px;"><i class="material-icons" style="color: white; padding-left: 15%;">shopping_cart</i></li>
  <li class="divider"></li>
  <li><a href="livros.php?category=acao&page=1">A&Ccedil;&Atilde;O</a></li>
  <li class="divider"></li>
  <li><a href="livros.php?category=aventura&page=1">AVENTURA</a></li>
  <li class="divider"></li>
  <li><a href="livros.php?category=comedia&page=1">COM&Eacute;DIA</a></li>
  <li class="divider"></li>
  <li><a href="livros.php?category=romance&page=1">ROMANCE</a></li>
  <li class="divider"></li>
  <li><a href="livros.php?category=suspense&page=1">SUSPENSE</a></li>
  <li class="divider"></li>
</ul>



<nav class="navbar-fixed #0091ea light-blue accent-4" style="padding: 0px 100px 50px 10px;">
  <div class="nav-wrapper">
    <a href="index.php" id="brand-logo"><img src="img/logo.png"   width="90px"></a>
    <a href="#" class="sidenav-trigger" data-target="mobile-nav">
      <i class="material-icons">menu</i>
    </a>

    <ul class="right hide-on-med-and-down">
        <!-- Dropdown Trigger -->
        <li><a class="dropdown-trigger" href="#!" data-target="dropdown1">LOJA<i class="material-icons left">shopping_cart</i></a></li>
        <li><a href="index.php#destaque">DESTAQUES<i class="material-icons left">import_contacts</i></a></li>
        <li><a href="index.php#sobre">SOBRE<i class="material-icons left">supervisor_account</i></a></li>
        <li><a href="index.php#localizacao">LOCALIZA&Ccedil;&Atilde;O<i class="material-icons left">place</i></a></li>
        <?php 
    		if(isset($_SESSION['id'])){
    			echo '<li><a href="logout.php?log=out">Sair</a></li>';
    		} else{
    			echo '<li><a href="cadastro.php">Cadastrar</a></li>';
    			echo '<li><a href="loginForm.php">Acessar</a></li>';
    		}
        ?>
    </ul>
  </div>

<!--BARRA DE PESQUISA -->
<form action="livros.php" method="GET">
    <label for="busca">Buscar</label>                  
        <div class="container">  
            <input type="searchh" id="busca" name="busca" style="max-width: 290px">
             <button type="submit"><img src="img/lupa.png" width="25px" height="25px"></button>
        </div>
                      
</form>
</nav>

<!--MENU MOBILE-->
<ul class="sidenav" id="mobile-nav">
  <li><a href="#">LOJA<i class="material-icons left">shopping_cart</i></a></li>
  <li><a href="livros.php?category=acao&page=1">A&Ccedil;&Atilde;O</a></li>
  <li><a href="livros.php?category=aventura&page=1">AVENTURA</a></li>
  <li><a href="livros.php?category=comedia&page=1">COM&Eacute;DIA</a></li>
  <li><a href="livros.php?category=romance&page=1">ROMANCE</a></li>
  <li><a href="livros.php?category=suspense&page=1">SUSPENSE</a></li>
  <li class="divider"></li>
  <li><a href="#destaque">DESTAQUES<i class="material-icons left">import_contacts</i></a></li>
  <li><a href="#sobre">SOBRE<i class="material-icons left">supervisor_account</i></a></li>
  <li><a href="#localizacao">LOCALIZA&Ccedil;&Atilde;<i class="material-icons left">place</i></a></li>
  <?php 
  if(isset($_SESSION['id'])){
    echo '<li><a href="logout.php?log=out">Sair</a></li>';
  } else{
    echo '<li><a href="cadastro.php">Cadastrar</a></li>';
    echo '<li><a href="loginForm.php">Acessar</a></li>';
  }
  ?> 
</ul>
<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "users";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);


//se tenta acessar direto pela url, redie
if(!isset($_GET['livro'])){
	header("Location: index.php");
}

//seleciona os dados do livro cuja id foi passada
$sql = "SELECT * FROM books WHERE id = ".$_GET['livro'];
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$price = "R$".sprintf("%0.2f", $row['price']);
$lastPrice = "R$".sprintf("%0.2f", $row['lastPrice']);
$cover = $row['cover'];
$name = $row['name'];
$bookId = $row['id'];
$description = $row['description'];



//exibição do produto
	echo'<div class="productBox">';
		echo'<div class="productCover">';
			echo '<img class="materialboxed" src="'.$cover.'"/>';
		echo '</div>';
		echo '<div class="productText">';
			echo'<span class="productName">'.$name.'</span><br>';
			echo'<p class="productDescription">'.$description.'</p>';
			if($price <= $lastPrice){
				echo '<span class="productHashedPrice">'.$lastPrice.'</span><br><span class="productPrice">'.$price."</span>";
			} else {
				echo '<span class="productPrice">'.$price."</span>";
			}
			echo '<form method="POST" action="comprar.php"><input type="numeric" style="display:hidden; width:0px; height: 0px; position: absolute; top: 0; left: 0;" name="bookId" value="'.$bookId.'">';
			echo '<button method="POST" type="submit" action="comprar.php" name="addToCart" class="addToCart"><i class="fas fa-cart-plus"></i></button></form>';
		echo '</div>';
	echo '</div>';


include("footer.php");
