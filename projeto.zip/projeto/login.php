<?php
//começa a sessão usada pra logar
session_start();

if(isset($_POST['submit'])){
	
	$dbServername = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbName = "users";

	$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

		
	$uid = mysqli_real_escape_string($conn, $_POST['uid']);
	$pwd = mysqli_real_escape_string($conn, $_POST['pwd']);
	
	//error handlers
	//checa input vazio
	if(empty($uid) || empty($pwd)){
		header("Location: loginForm.php?erro=vazio");
		exit();
	} else {
		//checa se o usuario OU email é igual o que ta na db
		$sql = "SELECT * FROM users WHERE uid = '$uid' OR email ='$uid'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		//checa se encontra o usuario>
		if($resultCheck < 1){
			header("Location: loginForm.php?erro=uidErrado");
			exit();
		} else {
			if($row = mysqli_fetch_assoc($result)){
				//de-hash a senha
				//check se é igual a da db
				$hashedPwdCheck = password_verify($pwd, $row['pwd']);
				//se não é igual>
				if($hashedPwdCheck == false){
					header("Location: loginForm.php?erro=error");
					exit();
				} else if ($hashedPwdCheck == true){
					//loga o usuario
					//passa variaveis pra sessão
					$_SESSION['id'] = $row['id'];
					$_SESSION['name'] = $row['name'];
					$_SESSION['email'] = $row['email'];
					$_SESSION['uid'] = $row['uid'];
					header("Location: index.php");
					exit();
				}
					
			}
		}
	}
} else {
	header("Location: loginForm.php?erro=error");
	exit();
}

