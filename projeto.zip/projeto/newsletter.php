<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "users";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);



	if (isset($_POST['nlButton'])) {
		if(isset($_POST['nlEmail'])){
			$mail = mysqli_real_escape_string($conn, $_POST['nlEmail']);
			if(!filter_var($mail, FILTER_VALIDATE_EMAIL)){
				header("Location: index.php?erro=email");
				exit();
			} else{
				$sql = "INSERT INTO maillist(email) values('$mail')";
				mysqli_query($conn,$sql);
				header("Location: index.php?erro=emailSuccess");
				exit();
			}
		}
	}



