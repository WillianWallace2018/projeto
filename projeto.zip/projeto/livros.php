<?php 
include("header.php");

//conect
$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "users";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

//se preço alterado for maior que o anterior seta pra 0

$sql = "UPDATE books SET lastPrice=0 WHERE price > lastPrice OR price = lastPrice";
$result = mysqli_query($conn, $sql);



//view
function displayBook($name, $cover, $link, $price, $lastPrice) {
  if($price < $lastPrice){
    echo('
        <div class="bookCover">
          <a href="'.$link.'">
            <img src="'.$cover.'">
          </a><h2 class="priceCover">R$'.sprintf("%0.2f", $price).'<br><span class="hashedPrice">R$'.sprintf("%0.2f", $lastPrice).'</span></h2>
          <span class="priceSeeMore"><a href="'.$link.'">COMPRAR</a></span>
        </div>
      ');

  }else{
    echo('
        <div class="bookCover">
          <a href="'.$link.'">
            <img src="'.$cover.'">
          </a><h2 class="priceCover">R$'.sprintf("%0.2f", $price).'</h2>
          <span class="priceSeeMore"><a href="'.$link.'">COMPRAR</a></span>
        </div>
      ');
  }
}

////////
//paginator

//checa se tem pagina, seta pra int, else manda pra page 1
if(isset($_GET['category']))
$category = $_GET['category'];
if(!$page = isset($_GET['page'])){
  $page = 1;
} else {
  $page = (int)$_GET['page'];
}
if($page <= 0){
  $page = 1;
}
//maximo exibido
$resultsPerPage =15;
//pega resultado da db
//limita baseado no resultado dado
$limitPage = ($page-1)*$resultsPerPage;

if(isset($_GET['category'])){
  $sql = 'SELECT * FROM books where category = "'.$category.'"';
}else if(isset($_GET['busca'])){
  $busca = $_GET['busca'];
  $sql = 'SELECT * FROM books where name like "%'.$busca.'%" || description like "%'.$busca.'%" || category like "%'.$busca.'%"';
}
else{
  $sql = 'SELECT * FROM books';
}
$result = mysqli_query($conn, $sql);
$numberOfResults = mysqli_num_rows($result);


//define limit e offset dos resultados e busca categoria
if(!isset($_GET['category'])){
  $sql = 'SELECT * FROM books LIMIT '.$limitPage.','.$resultsPerPage;
} else{
  $sql = 'SELECT * FROM books having category = "'.$category.'" LIMIT '.$limitPage.' , '.$resultsPerPage;
}
$result = mysqli_query($conn, $sql);


////////
//chamada da função de exibição
echo '<div class="coversBox">';
while($row = mysqli_fetch_array($result)){
  $price = $row['price'];
  $cover = $row['cover'];
  $link = "product.php?livro=".$row['id'];
  $lastPrice = $row['lastPrice'];
  $name = $row['name'];
  displayBook($name, $cover, $link, $price, $lastPrice);
}
echo('</div>');

//*sem ceil corta floats
$numberOfPages = ceil($numberOfResults/$resultsPerPage);
//exibe o link pra mudar paginas
echo '<div class="pageNumber">';

if($page > 1){
      echo '<a href="'.$_SERVER['PHP_SELF'];
      if(isset($_GET['category'])){
        echo'?category='.$category.'&page=1"><i class="fas fa-angle-double-left"></i></a>';
      } else{
        echo '?page=1"><i class="fas fa-angle-double-left"></i></a>';
      }
      echo '<a href="'.$_SERVER['PHP_SELF'];
      if(isset($_GET['category'])){
        echo '?category='.$category.'&page='.($page-1).'"><i class="fas fa-chevron-circle-left"></i></a>';
      } else{
        echo '?page='.($page-1).'"><i class="fas fa-chevron-circle-left"></i></a>';
      }
}
//numeros
for($i = 1; $i <= $numberOfPages; $i++){
  echo '<a href="'.$_SERVER['PHP_SELF'];
  if(isset($category)){
    echo '?category='.$category.'&page='.$i.'">'.$i.'</a>';
  } else{
    echo '?page='.$i.'">'.$i.'</a>';
  }
}
if($page < $numberOfPages){
      echo '<a href="'.$_SERVER['PHP_SELF'];
      if(isset($_GET['category'])){
        echo '?category='.$category.'&page='.($page+1).'"><i class="fas fa-chevron-circle-right"></i></a>';
      } else{
        echo '?page='.($page+1).'"><i class="fas fa-chevron-circle-right"></i></a>';
      }
      echo '<a href="'.$_SERVER['PHP_SELF'];
      if(isset($_GET['category'])){
        echo '?category='.$category.'&page='.$numberOfPages.'"><i class="fas fa-angle-double-right"></i></a>';
      } else{
        echo '?page='.$numberOfPages.'"><i class="fas fa-angle-double-right"></i></a>';
      }
}

echo '</div>';




include("footer.php");